# Straight Hands > 2021-11-11 2:38pm
https://universe.roboflow.com/jeffery260017-gmail-com/straight-hands

Provided by a Roboflow user
License: CC BY 4.0

